# -*- coding: utf-8 -*-
import os

import threading
import time

class Variable():
    def __init__(self):
        self.semaphoreA = threading.Semaphore(2)
        self.semaphoreG = threading.Semaphore(0)
        self.val = None
    def assign(self,val):
        self.semaphoreA.acquire()
        if(self.val==None):
            self.val = val
            self.semaphoreG.release()
            self.semaphoreG.release()
        else:
            raise AttributeError("Impossible de réassigner la variable.")
        self.semaphoreA.release()
    def get(self):
        self.semaphoreG.acquire()
        v = self.val
        self.semaphoreG.release()
        return v

def est_bisextile(year):
  return ((year%4==0) and ((year%100 != 0) or year%400==0))

def first_days(to):
  first = {}
  day = 1
  first[1900]=day
  for i in range(1901,to+1):
    leap = 1
    if(est_bisextile(i)):
      leap=2
    day=(day+leap-1)%7+1
    first[i]=day
  return first

def first_day_months(years):
  first = {}
  number = {}
  for i in (1,3,5,7,8,10,12):
    number[i]=31
  for i in {4,6,9,11}:
    number[i]=30
  number[2]=28
  numbers = {True: number, False: number.copy()}
  numbers[True][2]=29
  previous = ()

  for i in years:
    first[i]={}
    for j in range(1,13):
      if(previous==()):
        first[i][j]=1
        previous = (1,31,i,j)
      else:
        first[i][j]= (previous[0]+previous[1]-1)%7+1
        previous = (first[i][j],numbers[est_bisextile(i)][j],i,j)
  return first

def sundays(firsts):
  somme = 0
  for i in  firsts:
    for m in firsts[i]:
      if(firsts[i][m]==7):
        somme+=1
  return somme
        
class UBListe(list):
    def __init__(self):
        self.semaphore = threading.Semaphore(0)
        self.closed = False
    def add(self,element):
            self.append(element)
            self.semaphore.release()
    def get(self):
        while not (len(self)==0 and self.closed) :
            self.semaphore.acquire()
            if(len(self)>0):
                yield self.pop(0)
        
    def close(self):
        self.closed = True
        self.semaphore.release()

    def closed(self):
        return self.closed

class Port():
    def __init__(self,liste_vide):
        self.liste = liste_vide
    def send(self,message):
        self.liste.add(message)
    def close(self):
        self.liste.close()

def PortObject(ubliste,procedure):
    for g in ubliste.get():
        procedure(g)
def prints(s):
    print(s)

print("")
paageageageae = [";m;a;;;;;;;;;;;;;;;;;;;;;;;;;;;;;i;;;;;;;s;;;;;;;;;;o;n;1",";m;;;a;;;i;;s;;;;;;;;;;o;n;2;;;;;;",";;ma;i;s;o;n;3","ep;i;c;;;;;;eri;e;","s;;c;i;e;r;i;e","t;a;v;e;r;n;e;"]
pzuirhfe = ";I;l; ;m;a;n;q;u;e;:;"
isaaeaegggrhfe = 0
for b in paageageageae:
    if not os.path.isdir(b.replace(";","")):
        isaaeaegggrhfe = 1
        pzuirhfe=pzuirhfe+" "+b
if isaaeaegggrhfe:
    print((";C;h;e;f;:;; "+pzuirhfe+" . ;R;e;v;e;ne;z;;;;; ;m;;e; ;v;o;i;r; ;;;q;u;a;n;;d; ;ç;;;a; ;;s;e;;;r;a; ;f;;a;i;;;t; ;;;!;;").replace(";",""))

if os.path.isdir(";t;;a;;;;;;;v;;;;;er;n;e;;;".replace(";","")):
    if not os.path.isfile(";t;a;v;e;;r;;;;;n;e;/;h;om;;;;;m;e;_;j;o;;;;;;y;;e;;;;;;;u;;;x".replace(";","")) and not os.path.isfile(";t;a;v;e;r;ne;/;h;o;m;m;e;_;d;é;s;e;s;p;é;r;é;".replace(";","")):
        print(";C;h;e;f;:; ;V;o;u;s; ;n;';av;;;;;e;z; p;a;s; ;;a;c;c;o;m;;;;p;ag;n;é; ;l;';h;o;m;m;e; ;d;és;es;p;ér;é; ;d;a;n;s; ;l;a; ;t;a;v;e;r;n;e; ;! F;a;i;t;e;s;-l;e; p;u;i;s; ;r;eve;n;e;z; ;m;;;e; ;v;;;o;;ir;;;; ;;!;".replace(";",""))
        isaaeaegggrhfe = 1

if isaaeaegggrhfe==0 and not os.path.isfile(";t;;;;;;;;a;;;;v;;;;;e;;;;r;n;;;e;;;;;;;;/;h;o;m;m;;e_;;;;j;o;;y;e;u;;;;x;;".replace(";","")):
    print(";M;e;r;c;i; ;m;o;n; ;a;m;i; ;!; ;J;';a;ur;a;;;;i;;;s un p;;;;e;t;i;t ;s;e;r;vi;c;e; ;à; ;t;e; ;d;em;a;n;d;e;r;:; l;';h;o;m;;;m;;e;; ;;d;;a;;n;;s;; ;;;;;;l;;;a;;;; ;t;a;v;;;;;e;;;r;;n;e; n;;;';e;s;t; p;l;u;s ;d;;;é;s;es;p;;é;ré; ;m;ai;n;;t;e;n;an;t;. ; ;Po;u;rr;a;i;s-;t;u ;l;e ;r;en;o;mm;e;r ;'h;om;m;e;_;jo;ye;u;x; ;;?;;;;".replace(";",""))
    print(";P;o;u;r ;r;en;o;mm;er; ;u;n ;l;;i;e;u;,; u;n;e;; ;pe;r;s;;o;n;ne;,; ;u;n ;p;a;nn;e;a;u;, ;t;u; p;;eu;x; ;u;t;i;l;is;e;r; ;';mv;';.;;;;;".replace(";",""))
    print("E;x;e;m;pl;e;:; ;';m;v ;c;h;e;f;;;.;p;y;; ;r;o;i;.;;p;;y'; ;;c;h;a;n;ge; ;m;on; ;no;m; ;en; ;';r;;o;i.;p;y;';;;;".replace(";",""))
    print("V;;a ;d;;a;n;;;s; ;;l;;;a; ;;;;;t;;;a;v;;e;;;r;n;e;;;; ;r;e;;no;m;;;;m;;er; ;ce; ;pa;;;u;vr;e; ;ho;m;me; ;;et; ;r;ev;i;e;n;s ;m;e ;v;o;;i;r; ;;!;".replace(";",""))
elif isaaeaegggrhfe==0:
    print(";M;;e;rc;i; ;b;e;a;uc;o;u;p; !; ; ;Tu; ;v;o;is; ;l;e; ;ch;â;t;e;a;u ;d;a;ns; ;le; ;v;i;ll;;a;g;e ;d;e ;l;';au;t;r;;e; c;ô;t;;é; d;e;; ;la; ;f;o;r;êt; ;?; ;J;e; ;v;a;i;s ;t;e; d;o;nn;e;r; ;la; ;c;lé; ;p;o;ur; ;y; ;e;;;;nt;r;er;.;".replace(";",""))
    print(";L;o;r;s;;;;q;;u;e ;t;u; ;n;';;a;s; ;p;as; ;l;;;;e; ;d;;;;r;o;i;;;;t; ;d;;'e;;;n;t;r;;;;;e;r; ;q;ue;l;;;;q;u;;;;e ;p;;;ar;t;,; ;tu; ;d;oi;s;;;; ;u;t;i;l;i;se;r; ';c;h;mo;d; u;+;xr;'.".replace(";",""))
    print(";;;;;E;;;x;e;;;;;;m;;;p;;;;l;e:; ;s;i; ;;;;t;;;;u;;;;; ;n;';av;;;;a;;;;i;s; ;pa;;;;;;;s ;l;a ;p;er;m;i;s;;;;s;i;on; ;;;;d';e;n;t;;;r;e;r ;d;a;ns; ;l;';é;p;;;i;ce;r;ie;,; ;t;u ;p;ou;r;;;;;r;a;is; ;es;s;ay;e;r;;;: ;';c;h;;;;;m;od; ;;;;u;+x;r;;; ;e;p;;;;i;c;;e;r;i;e;;';;;;".replace(";",""))

print("")

def encoderNoms(x):
    print("Encodez %d noms: " ) % x
    noms = []
    for i in range(x):
        noms.append(raw_input())
    
    print("Les noms sont "),
    for n in noms:
        print("%s ") % n ,
    
    print("Le 1er est: %s") % noms[0] 
    
    print("Quel nom remplacer (1- %d ) ?") % (x)
    num = int(raw_input())-1
    noms[num] = raw_input("Remplacement: ")
    
    print(noms)
        
def maximum(a,b,c):
    if(a>= b and a>= c):
        return a
    elif(b>=c):
        return b
    else:
        return c
        

class CompteBancaire:
    def __init__(self, nom, numero):
        self.nom = nom
        self.numero = numero
        self.solde = 0.0
        
    def afficherSolde(self):
        print(self.solde)
        
    def depot(self,s):
        self.solde+=s
        
    def retrait(self,s):
        if(s>=self.solde):
            self.solde-=s
            return True
        else:
            print("Pas assez d'argent pour ce retrait.")
            return False
    

class CompteEpargne(CompteBancaire):
    def __init__(self,interet,nom,numero):
        CompteBancaire.__init__(self,nom,numero)
        self.interet = interet
    def ajouterInterets(self):
        self.solde+=(self.solde)*self.interet
     
import math



def chemin_triangle(triangle):
  resultat = []
  for i in range(0, len(triangle)):
    resultat.append([])
    for j in range(0, len(triangle[i])):
      app=(triangle[i][j])
      origine = (i-1,j-1)
      if(i>0):
        if(j==0):
          origine = (i-1,j)
          app+=resultat[i-1][j][0]
        elif(j==len(triangle[i-1])):
          app+=resultat[i-1][j-1][0]
        else:
          app+= max(resultat[i-1][j][0],resultat[i-1][j-1][0])
          if(resultat[i-1][j][0]>resultat[i-1][j-1][0]):
            origine = (i-1,j)
      resultat[i].append((app,origine))

  max_chemin = (0,0)
  for tupl  in resultat[len(resultat)-1]:
    if(max_chemin[0]<tupl[0]):
      max_chemin=tupl
  
  current = max_chemin
  chemin = []
  for i in range(0,len(resultat)):
    chemin.append(resultat[current[1][0]][current[1][1]])
    current = resultat[current[1][0]][current[1][1]]
  

  return resultat

def somme_chemin(chemin,triangle):
  current = max_tuple(chemin[-1])
  somme = current[0]

  while(current[1][0]>-1):

    somme += triangle[current[1][0]][current[1][1]]
    current = chemin[current[1][0]][current[1][1]]
  return somme
def max_tuple(l):
  maxi = l[0]
  for t in l:
    if(t[0]>maxi[0]):
      maxi = t
  return maxi

dict ={
1:{0:"",1:"one",2:"two",3:"three",4:"four",5:"five",6:"six",7:"seven",8:"eight",9:"nine"},
2:{2:"twenty",3:"thirty",4:"forty",5:"fifty"},
3:"hundred",
4:"one thousand",
10:"ten",11:"eleven",12:"twelve",13:"thirteen",15:"fifteen",18:"eighteen"
}

def digits(n):
  digits = []
  while(n>=1):
    i = n % 10
    digits.insert(0,i)
    n = (n-i)/10
  return digits 

def number_to_words(num):
  n = 0
  for i in range(0,len(num)):
    n=n*10+num[i]
  if(len(num)==1):
    return dict[1][num[0]]
  if(len(num)==2):
    n = num[0]*10+num[1]
    if(n in dict): 
      return dict[n]
    elif(num[-2] in dict[2]):
      ret = dict[2][num[-2]]
      num.pop(0)
      return ret +" "+number_to_words(num)
    elif(num[1] in dict[1] and num[0]==1): 
      return dict[1][num[1]]+"teen"
    else:
      return (dict[1][num[0]]+"ty"+" "+dict[1][num[1]]).replace("tt","t")
  if(len(num)==3):
    ret = "hundred"
    if(n==100):
      ret= "one hundred"
    if(n>100):
      ret = dict[1][num[0]]+" "+ret
      if(num[1]>0):
        num.pop(0)
        ret = ret+" and "+ number_to_words(num)
      elif(num[1]==0 and num[2]==0):
        ret = ret
      else:
        num.pop(0)
        num.pop(0)
        ret = ret+ " and "+ number_to_words(num)
    return ret 
  else:
    return dict[4]

def letter_count(min,max):
  numbers = ""
  for i in range(min,max+1):
    numbers+=number_to_words(digits(i))
  return numbers.replace(" ", "")


def generateTriangleNumber(n):
    return sum([x for x in range(1,n+1)])


def getFactors(n):
    factors = []
    for i in range(1,int(math.sqrt(n))+1):
        if(not n%i):
            factors.append(i)
            factors.append(n/i)
    return factors
    

factors = []
n = 0



def collatz(start, tabou, max):
  n = start
  count = 1 
  tabou[n]=1
  while(n>1):
    if(not n%2): 
      n/=2
    else: 
      n = 3*n +1
    count += 1
    tabou[n]=1

  m = max
  if(max[1]<count):
    m = (start,count)
  return m

def longest_chain(limite):
  i = 0
  max = (0,0)
  tabou = {}
  while(i<=limite):
    i+=1
    if(not i in tabou):
      max = collatz(i,tabou,max)
  return max
  
def triangle_pascal(n):
  ligne = []
  if(n<1):
    return ligne
  else:
    ligne = [1]
    i = 1
    while(i<n):
      ligne = next_pascal(ligne)
      i+=1
    return ligne

def next_pascal(l):
  i = 0
  next = [0 for x in range(len(l)+1)]
  while(i<len(next)):
    current = 0
    if(i<len(l)):
      current+= l[i]
    if(i>0):
      current+= l[i-1]
    next[i]= current
    i+=1
  return next
  

